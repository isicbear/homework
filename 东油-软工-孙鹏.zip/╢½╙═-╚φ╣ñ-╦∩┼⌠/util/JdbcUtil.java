package com.train.day13.util;

import com.train.day13.practice.Hero;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @author ：孙鹏
 * @date ：Created in 2019/8/6 0006 16:23
 * @description：jdbc工具类 包含数据库连接、通用的查询方法与资源的关闭三个方法
 * @version:
 */
public class JdbcUtil {
    public JdbcUtil() {
    }

    private static final JdbcUtil JDBC_UTIL = new JdbcUtil();

    public static JdbcUtil getInstance() {
        return JDBC_UTIL;
    }

    /**
     * 通过配置文件获取数据库连接
     *
     * @return 返回连接
     * @throws IOException
     */
    public Connection getConnection() throws IOException {
        Properties properties = new Properties();
        String filepath = JdbcUtil.class.getResource("/").getFile().toString() + "jdbc.properties";
        InputStream is = new FileInputStream(filepath);
        properties.load(is);
        Connection connection = null;
        try {
            Class.forName(properties.get("driver").toString());
            connection = DriverManager.getConnection(properties.get("url").toString(), properties.get("user").toString(), properties.get("password").toString());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * 通用的查询方法
     * 反射没用好 以后在说
     * @param classpath
     * @param args
     * @return
     */
    public  List findHero(String classpath, String sql, Object... args) {
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Hero> heroList=new ArrayList<>();
        try {
            connection = JDBC_UTIL.getConnection();
            ps = connection.prepareStatement(sql);
            for (int i = 1; i <= args.length; i++) {
                ps.setObject(i, args[i - 1]);
            }
            rs = ps.executeQuery();
            while (rs.next()){
                Hero hero=new Hero();
                hero.setId(rs.getInt("id"));
                hero.setSno(rs.getString("sno"));
                hero.setSname(rs.getString("sname"));
                hero.setSex(rs.getString("ssex"));
                hero.setSage(rs.getInt("sage"));
                heroList.add(hero);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeRes(rs);
            closeRes(ps);
            closeRes(connection);
        }
        return heroList;
    }

    /**
     * 关闭资源
     *
     * @param res 待关闭资源
     */
    public void closeRes(AutoCloseable res) {
        if (null != res) {
            try {
                res.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
