package com.train.day13.practice;

import com.train.day13.util.JdbcUtil;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ：孙鹏
 * @date ：Created in 2019/8/6 0006 16:58
 * @description：IHeroOperation的实现类
 * @version:
 */
public class IHeroOperationImp1 implements IHeroOperation {
    /**
     * 测试第二题
     */
    @Test
    public void test1() {
        List<Hero> heroList = findByUserNameLike("h");
        for (Hero h : heroList) {
            System.out.println(h);
        }
    }
    /**
     * 测试第三题
     */
    @Test
    public void test2() {
        List<Hero> heroList = findOrderByUserName();
        for (Hero h : heroList) {
            System.out.println(h);
        }
    }
    /**
     * 测试第四题
     */
    @Test
    public void test3() {
        List<Hero> heroList = findByUserNameLikeOrderLimit("h",2,2);
        for (Hero h : heroList) {
            System.out.println(h);
        }
    }

    /**
     * 第二题
     * @return
     */
    @Override
    public List<Hero> findByUserNameLike(String userName) {
        List<Hero> heroList = new ArrayList<>();
        String str = "select * from hero where sname like CONCAT(?,'%')";
        JdbcUtil jdbcUtil = JdbcUtil.getInstance();
        heroList = jdbcUtil.findHero(null, str, userName);
        System.out.println("hua");
        return heroList;
    }

    /**
     * 第三题
     * @return
     */
    @Override
    public List<Hero> findOrderByUserName() {
        List<Hero> heroList = new ArrayList<>();
        String str = "select * from hero order by sname DESC";
        JdbcUtil jdbcUtil = JdbcUtil.getInstance();
        heroList = jdbcUtil.findHero(null, str);
        System.out.println("hua");
        return heroList;
    }
    /**
     * 第四题
     * @return
     */
    @Override
    public List<Hero> findByUserNameLikeOrderLimit(String userName, int currPage, int pageSize) {
        List<Hero> heroList = new ArrayList<>();
        String str = "select * from hero where sname like CONCAT(?,'%') ORDER BY sage LIMIT ?,?";
        JdbcUtil jdbcUtil = JdbcUtil.getInstance();
        heroList = jdbcUtil.findHero(null, str, userName,currPage,pageSize);
        System.out.println("hua");
        return heroList;
    }
}
