package com.train.day13.practice;

/**
 * @author ：孙鹏
 * @date ：Created in 2019/8/6 0006 16:52
 * @description：hero表的操作接口
 * @version:
 */

import java.util.List;

/**
 * 2.根据昨天练习的表，完成名称或其他字段模糊查找
 * ​                  方法名，如：findByUserNameLike(String userName)
 * 3.根据昨天练习的表，完成根据某个字段进行排序（降序）的操作
 * ​                 方法名，如：findOrderByUserName()
 * 4.根据昨天练习的表，完成根据某个字段模糊查找并排序（升序），然后分页获取第二页数据的操作（每页显示2条）
 * ​                方法名，如：findByUserNameLikeOrderLimit(String userName，int currPage, int pageSize)
 *                  userName:用户名
 *                  currPage:当前页
 *                  pageSize:每页显示的数量
 */
public interface IHeroOperation {
    // 2.根据昨天练习的表，完成名称或其他字段模糊查找
    List<Hero> findByUserNameLike(String userName);
    // 3.根据昨天练习的表，完成根据某个字段进行排序（降序）的操作
    List<Hero> findOrderByUserName();
    // 4.根据昨天练习的表，完成根据某个字段模糊查找并排序（升序），然后分页获取第二页数据的操作（每页显示2条）
    List<Hero> findByUserNameLikeOrderLimit(String userName, int currPage, int pageSize);
}
