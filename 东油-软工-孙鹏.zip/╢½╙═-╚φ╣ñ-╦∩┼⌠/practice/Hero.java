package com.train.day13.practice;

/**
 * @author ：孙鹏
 * @date ：Created in 2019/8/6 0006 16:54
 * @description：hero表对应的实体
 * @version:
 */
public class Hero {
    private int id;
    private String sno;
    private String sname;
    private String sex;
    private int sage;

    public Hero() {
    }

    public Hero(String sno, String sname, String sex, int sage) {
        this.sno = sno;
        this.sname = sname;
        this.sex = sex;
        this.sage = sage;
    }

    @Override
    public String toString() {
        return "Hero{" +
                "id=" + id +
                ", sno='" + sno + '\'' +
                ", sname='" + sname + '\'' +
                ", sex='" + sex + '\'' +
                ", sage=" + sage +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getSage() {
        return sage;
    }

    public void setSage(int sage) {
        this.sage = sage;
    }
}
