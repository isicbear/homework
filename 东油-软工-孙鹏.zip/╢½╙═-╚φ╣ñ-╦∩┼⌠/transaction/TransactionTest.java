package com.train.day13.transaction;

import com.train.day13.util.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author ：孙鹏
 * @date ：Created in 2019/8/6 0006 16:42
 * @description： 练习事务的操作
 * @version:
 */
public class TransactionTest {
    public static void main(String[] args) {
        JdbcUtil jdbcUtil = JdbcUtil.getInstance();
        Connection connection = null;
        PreparedStatement ps=null;
        try {
            connection = jdbcUtil.getConnection();
            connection.setAutoCommit(false);// 设置不默认提交
            String sql="insert into `order` values (null,1,20)";// insert
            ps=connection.prepareStatement(sql);
            ps.executeUpdate();
            String sql1="update good set storge = storge - 20 where id = 1";// update
            ps=connection.prepareStatement(sql1);
            ps.executeUpdate();
            connection.commit();// 手动提交
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            jdbcUtil.closeRes(ps);
            jdbcUtil.closeRes(connection);
        }
    }
}
